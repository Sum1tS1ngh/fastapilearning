import sys 
print(sys.path)
path=r'C:\Users\OM\eclipse-workspace\02_5Aug2024_SocGen\Day3\module_\case1'
sys.path.append(path)
print(sys.path)
from dongli_1 import odd_even,t,Area
print("===========================calling_1.py File is executed======================================")
g=odd_even('8')
print(g)
