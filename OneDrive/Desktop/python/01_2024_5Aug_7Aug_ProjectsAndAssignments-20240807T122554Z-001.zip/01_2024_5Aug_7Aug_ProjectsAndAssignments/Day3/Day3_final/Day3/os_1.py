import os 
# print(os.getcwd())
# print(os.listdir())
# path=os.path.join(os.getcwd(),'namespace_')
# print(path)
# print(os.path.exists(path))
# if os.path.exists(path) :
#     os.chdir(path)
#     print(os.getcwd())
#     print(os.listdir())
# #     os.mkdir(r'newfolder\bin')#create folder if base dir exists
# #     os.makedirs(r'newfolder2\bin')
# #    os.rename(r'newfolder\bin',r'newfolder\data')
# #     os.rmdir(r'newfolder\data')#delete only the sub dir.
#     os.removedirs(r'newfolder\data')
#     print(os.listdir())
# path=r"C:\Users\OM\eclipse-workspace\02_5Aug2024_SocGen\Day2\files"
# os.chdir(path)
# print(os.listdir())
# fh=open('lines.txt')
# print(fh)
path=r'C:\Users\OM\eclipse-workspace\02_5Aug2024_SocGen\Day3\module_\case1'
os.chdir(path)
print(os.listdir())

# from dongli_1 import * # Error :- ModuleNotFoundError: No module named 'dongli_1'














