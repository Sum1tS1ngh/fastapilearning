obj_1=lambda x=9,y=6:x**2+y**2+2*x*y+56.8/x
print(type(obj_1))
#X=9,Y=6
#####calling of the Function ################
h=obj_1(9,6)
print(h)

h=obj_1(y=6,x=9)
print(h)

h=obj_1()
print(h)