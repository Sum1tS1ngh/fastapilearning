from bin.sys1.dongli_1 import odd_even,t,Area
print("===========================calling_1.py File is executed======================================")
g=odd_even('8')
print(g)
print(__name__)#__main__
