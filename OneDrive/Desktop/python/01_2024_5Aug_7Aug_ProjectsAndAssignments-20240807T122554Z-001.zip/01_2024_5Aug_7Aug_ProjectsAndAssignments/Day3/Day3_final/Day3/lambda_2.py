obj_1=(lambda x=9,y=6:x**2+y**2+2*x*y+56.8/x)(5,8)
print(obj_1)

j=(lambda x : "Odd" if x%2==1 else "Even")(10)
print(j)

(lambda :print("Test"))()

seq=[78,56,89,34,99,37,89]
f=list(filter(lambda i : i%2!=0 ,seq))
print(f)
str1="I122N33D343I33@333     D454E34r3L444H67734I"
print(str1)
f=''.join(filter(lambda i : not i.isdigit()  ,str1))
print(f)
