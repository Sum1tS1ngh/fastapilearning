from tkinter import *
win=Tk()
win.title("Nishant")
win.config(background="#92857c")
def demo():
    g=var2.get()#get the value from the option Menu
    c.delete('1.0', END)#clear the Text Box
    c.insert(END, g)#insert the Value into The Text Box
    
    
a=Button(win,command=demo,text='Press Me',bg='#928584',fg='#fff',font=('Courgette',11))
a.grid(row=0,column=0)

var=StringVar()
b=Entry(win,text=var,bg='#928584',fg='#fff',font=('Courgette',11))
b.grid(row=0,column=1)

c=Text(win,height=1,width=22,bg='#928584',fg='#fff',font=('Courgette',11))
c.grid(row=0,column=2)

d=Label(win,text="OptionMenu:-",bg='#928584',fg='#fff',font=('Courgette',11))
d.grid(row=1,column=1)


var2=StringVar() # IntVar()
e=OptionMenu(win,var2,"BJP","I.N.D.I.A","Others","NOTA")
e.grid(row=1,column=2)

win.mainloop()