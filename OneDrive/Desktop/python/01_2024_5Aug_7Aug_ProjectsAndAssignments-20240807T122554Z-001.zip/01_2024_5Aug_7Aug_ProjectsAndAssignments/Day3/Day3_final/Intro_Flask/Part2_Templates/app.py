from flask import Flask,render_template

app1=Flask(__name__)# return the Module Name # WSGI Object
print(app1)

@app1.route('/')
@app1.route('/home')
def home():
    return render_template('home.html')


@app1.route('/about')
def about():
    return render_template('about.html')


@app1.errorhandler(404)
def page_not_found(e):
    print(e.__class__.__name__)
    print(e)
    return render_template('404.html')

if __name__ == '__main__':
    app1.run(debug=True,port='5000')
