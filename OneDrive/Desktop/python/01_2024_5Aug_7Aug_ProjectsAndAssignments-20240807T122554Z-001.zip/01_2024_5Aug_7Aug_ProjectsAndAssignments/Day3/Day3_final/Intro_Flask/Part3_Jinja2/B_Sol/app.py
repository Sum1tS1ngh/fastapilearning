from flask import Flask,render_template

app1=Flask(__name__)# return the Module Name # WSGI Object
print(app1)

@app1.route('/')
@app1.route('/home')
def home():
    posts = [{
    'author': 'Nishant',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date_posted': 'July 26, 2022'
    },
    {'author': 'Dr Wu',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date_posted': 'July 27, 2022' }
]
    return render_template('home.html',posts=posts,title='Home')


@app1.route('/about')
def about():
    return render_template('about.html',title='About')


@app1.errorhandler(404)
def page_not_found(e):
    print(e.__class__.__name__)
    print(e)
    return render_template('404.html',title='404 Not Found')

if __name__ == '__main__':
    app1.run(debug=True,port='5000')
