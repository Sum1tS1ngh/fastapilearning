d={}
for i in range(1,6):
    name=input(f"Enter The {i}. Name:-")
    age=input(f"Enter the Age of {name}.")
    d[name]=age

print("Data created:",d)

input()
