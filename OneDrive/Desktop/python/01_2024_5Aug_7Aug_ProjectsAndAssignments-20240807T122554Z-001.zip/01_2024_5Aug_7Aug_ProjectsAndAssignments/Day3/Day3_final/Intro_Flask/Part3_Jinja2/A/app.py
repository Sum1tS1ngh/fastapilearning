from flask import Flask,render_template

app1=Flask(__name__)# return the Module Name # WSGI Object
print(app1)

@app1.route('/')
@app1.route('/home')
def home():
    data_names=["Manish","Baba","Test1232","Tata","Ratan","Nishant"]
    return render_template('home.html',data_names=data_names,title='Home')


@app1.route('/about')
def about():
    return render_template('about.html',title='About')


@app1.errorhandler(404)
def page_not_found(e):
    print(e.__class__.__name__)
    print(e)
    return render_template('404.html',title='404 Not Found')

if __name__ == '__main__':
    app1.run(debug=True,port='5000')
