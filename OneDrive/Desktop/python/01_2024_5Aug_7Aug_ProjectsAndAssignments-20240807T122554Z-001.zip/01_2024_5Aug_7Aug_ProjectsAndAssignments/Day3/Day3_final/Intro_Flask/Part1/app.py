from flask import Flask

app1=Flask(__name__)# return the Module Name # WSGI Object
print(app1)

@app1.route('/')
@app1.route('/home')
def home():
    return "Hello World ! This is Flask! App"


@app1.route('/about')
def about():
    return "<h1>This is about Page.</h1>"


@app1.errorhandler(404)
def page_not_found(e):
    return "Invalid URL!"

if __name__ == '__main__':
    app1.run(debug=True,port='5000')
