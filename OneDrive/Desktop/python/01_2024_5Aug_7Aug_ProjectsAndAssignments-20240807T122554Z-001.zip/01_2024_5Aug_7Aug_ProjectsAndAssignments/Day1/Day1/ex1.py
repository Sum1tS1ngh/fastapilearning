a=10
b=a+60

b # No Error, No Value Return
print(b)