a="NISHANT"
print(a)
b=a[3]
print(b)
#trying to delete
# TypeError: 'str' object doesn't support item deletion
# del a[3]
#trying to update 
#TypeError: 'str' object does not support item assignment
# a[3]=89
