a="Nishant"
b="Sharma"
c=a+" "+b
print(c)
g=(1,2,"Hello")
h=(90,78)
k=g+h
print(k)

