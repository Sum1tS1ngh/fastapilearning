# a="     this is NishANt HOuse!       "
# print(a,len(a))
# a=a.strip()#a.rstrip()#a.lstrip()
# print(a,len(a))
# b=a.swapcase()#a.lower()#a.upper()#a.capitalize()
# print(b,len(b))
a='132344'
b=a.isdigit()# True :- only for Digits chars
print(b)

a=' '
b=a.isspace()
print(a)


a="AbT"
b=a.isalpha()
print(b)

a="kal ho na ho.mp3"
b=a.__contains__('na')#a.startswith('kal')#a.endswith('.mp3')
print(b)