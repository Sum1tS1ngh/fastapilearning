# a=()# Empty Tuple Object
"""
a=(1,1.2,"Hello",(56,89),[90,91])
print(a)
print(id(a),type(a),len(a))
"""
#####
# create a one Value Tuple Object of UTKARSH ?
a=("UTKARSH",)# one Value Tuple Object
print(a)
print(id(a),type(a),len(a))
"""

name age dept 
"Raj"67 "It"
"Om" 89  "L&d"

[("Raj",'IT'),("Om",'L&D')]# NAME and age column with two rows 
[("Raj",),("Om",)]# name column with 2 Rows

"""