a=5*2
print(id(a))
b=10
print(a)
print(b)

print(id(a),id(b))
print(id(a)==id(b))
