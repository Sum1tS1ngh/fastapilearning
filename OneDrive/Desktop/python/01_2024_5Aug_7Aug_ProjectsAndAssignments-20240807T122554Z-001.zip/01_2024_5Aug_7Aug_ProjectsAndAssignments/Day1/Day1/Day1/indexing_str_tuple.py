##indexing 
"""
a="NISHANT"
print(a)
b=a[2]#S"
print(b)
"""
# a=(1,1.2,"Hello",(56,(89,78,("Hii",))),[90,91])
# print(a)
# print(id(a),type(a),len(a))
"""
b=a[2][-2]#"Hello">'l'
print(b)
#get the value "Hii" out from the tuple object a ?
h=a[-2][-1][-1][0]
# h=a[3][-1][-1][0]
print(h)
"""
#slicing 
a=(1,1.2,"Hello",(56,(89,78,("Hii",))),[90,91])
print(a)
print(id(a),type(a),len(a))
var=a[0:len(a):3]# 0:5:3> 0,3> (1,(56, (89, 78, ('Hii',))))
print(var)
var="NISHANT"
print(a)
b=var[::4]#0:len(var):4 > 0:7:4 > 0,4>NA
print(b)


