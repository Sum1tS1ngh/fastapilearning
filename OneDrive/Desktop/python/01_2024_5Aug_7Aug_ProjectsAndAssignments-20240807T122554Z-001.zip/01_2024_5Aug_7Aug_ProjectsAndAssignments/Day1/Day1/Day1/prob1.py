# a="NISHANT"
a="NISHANT SHARMA"
# a=[1,'1.2',1.2,[56,89],(67,[90])]
a=(1,1.2,"Hello",(56,(89,78,("Hii",))),[90,91])
print(a)
# reverse the whole seq's by fill the values of X and Y ?
d=a[-1:-(len(a)+1):-1]
print(d)
#TNAHSIN