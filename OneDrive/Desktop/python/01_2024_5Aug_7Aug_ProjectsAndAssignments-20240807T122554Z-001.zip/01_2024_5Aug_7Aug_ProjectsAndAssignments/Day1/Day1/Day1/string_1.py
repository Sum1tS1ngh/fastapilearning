"""
#one line input string > one line output string .
obj="The resignation comes after 300 people have died amid weeks of protest the authorities have sought to crush. Following a night of deadly violence that killed close to 100 on Sunday, tension had remained high on Monday as protesters called for a march on Dhaka and the army prepared to address the nation."
print(obj)

obj='The resignation comes after 300 people have died amid weeks of protest the authorities have sought to crush. Following a night of deadly violence that killed close to 100 on Sunday, tension had remained high on Monday as protesters called for a march on Dhaka and the army prepared to address the nation.'
print(obj)
# Multiline string object > one line output string 
obj='The resignation comes after 300 people have died \
amid weeks of protest the authorities have sought to \
crush. Following a night of deadly violence that killed \
close to 100 on Sunday, tension had remained high on Monday \
as protesters called for a march on Dhaka and the army \
prepared to address the nation.'
print(obj)
"""

var='This is "Nishant" House.'
print(var)

var2="This is Nishant's House."
print(var2)

var3='''This is "Nishant's" House.'''
print(var3)

# Multiline input string > Multiline Output String 

var4="The resignation comes after 300 people have died \n\
amid weeks of protest the \"authorities's\" have sought to \n\
crush. Following a night's of deadly violence that killed \n\
close to \"100\" on Sunday, tension's had remained high on Monday \n\
as protesters called for a march on Dhaka and the army \n\
prepared to address the nation."


print(var4)

# Multiline input string > Multiline Output String 
var5="""The resignation comes after 300 people have died 
amid weeks of protest the "authorities's" have sought to 
crush. Following a night's of deadly violence that killed 
close to "100" on Sunday, tension's had remained high on Monday 
as protesters called for a march on Dhaka and the army 
prepared to address the nation."""

print(var5)




