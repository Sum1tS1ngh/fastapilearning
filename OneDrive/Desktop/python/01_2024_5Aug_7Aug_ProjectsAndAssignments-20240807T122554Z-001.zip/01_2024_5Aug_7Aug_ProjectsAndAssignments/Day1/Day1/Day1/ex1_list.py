a=[]#empty list 
a=["Hello"]#one value list 
a=[1,'1.2',1.2,[56,89],(67,[90])]# list of the Values 

print(a)
print(id(a),type(a),len(a))
b=a[3]#[56,89]
b=a[-1][-1][0]#90
print(b)
#slicing 
b=a[3:]# 3:len(a):1 > 3:5:1> 3,4 > [[56,89],(67,[90])]
print(b)
