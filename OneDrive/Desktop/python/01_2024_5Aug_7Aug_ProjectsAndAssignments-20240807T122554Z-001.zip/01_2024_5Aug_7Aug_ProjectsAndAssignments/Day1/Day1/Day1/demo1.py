a=(1,1.2,"Hello",(56,(89,78,("Hii",))),[90,91])
print(a)

b=a[3]
print(b)
#Trying to update an value ?
#TypeError: 'tuple' object does not support item assignment
# a[3]=67
#Trying to delete an value ?
#TypeError: 'tuple' object doesn't support item deletion
# del a[3]