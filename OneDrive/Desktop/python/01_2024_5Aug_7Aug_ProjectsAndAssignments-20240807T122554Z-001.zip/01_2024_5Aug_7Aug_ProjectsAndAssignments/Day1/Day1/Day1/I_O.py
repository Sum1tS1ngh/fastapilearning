# a=input("Enter The Value:-")#string
# print(a)
# print(type(a))
# a=eval(a)#int(a)#float(a)#str()
# print(type(a))
# g=a*3
# print(g)
'''
print("Line-1 Winter is coming!",end='===')
print("Line-2 Winter is coming!")
print("Line-3 Winter is coming!",end=' ')
print("Winter is coming!",end=' ')

print('1','2',sep='^')



path="C:\\Users\OM\eclipse-workspace\\02_5Aug2024_SocGen\\nay1"
print(path)
'''
#raw-string
# path=r"C:\Users\OM\eclipse-workspace\02_5Aug2024_SocGen\nay1"
# print(path)

name="Manish1"
age=90 
out="The Name :-"+name+" Age:-"+str(age)
print(out)

#Format Method:-  
#automatic field numbering
out='The Name {}. Age :- {}.'.format(name,age)
print(out)

#manual field specification
out='The Name {1}. Age :- {0}.'.format(name,age)
print(out)

out='The Name {a}. Age :- {b}.'.format(a=name,b=age)
print(out)

#f-string method 
out=f'The Name {name}. Age :- {age}.'
print(out)















