fname=input("Enter the First Name:-")

if fname.lower()=='manish':
	
	lname=input("Enter the Last Name:-")
	if lname.upper()=="MEENA":
		print("Full Name Matched!")
	else:
		print("Only First Name matched!")

else:
	print("Nothing Matched!")



print("Done")