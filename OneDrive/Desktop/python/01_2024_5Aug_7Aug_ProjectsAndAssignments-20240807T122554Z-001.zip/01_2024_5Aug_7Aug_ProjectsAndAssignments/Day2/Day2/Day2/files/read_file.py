"""
file_object=open(filename,mode)
modes
############
r >read 
w> write 
r+> read/write 
a> append
x> create new file 
########binary file ###########
rb ,wb , rb+ 
############################
"""

fh=open('lines.txt','r')
print(fh)

for line in fh:
    print(line.strip())

fh.seek(0)
# d=fh.readline()# one line
d=fh.readlines()#list of the lines
print("==",d)

fh.close() #close the file object
# fh.readline()#ValueError: I/O operation on closed file.



