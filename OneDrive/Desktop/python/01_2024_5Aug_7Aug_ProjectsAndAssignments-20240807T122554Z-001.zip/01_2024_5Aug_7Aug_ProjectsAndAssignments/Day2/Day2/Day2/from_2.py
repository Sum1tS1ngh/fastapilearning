from math import pi,sin,factorial

g=sin(pi/6)
print(g)


h=factorial(6)

print(h)