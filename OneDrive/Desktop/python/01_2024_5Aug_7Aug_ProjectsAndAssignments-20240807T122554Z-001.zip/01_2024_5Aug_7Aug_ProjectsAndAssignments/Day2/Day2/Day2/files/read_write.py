fh=open('lines.txt','r')
out=open('out.txt','a')

for line in fh:
    if line.__contains__("hero"):
        print(line.strip(),file=out)
    
print("Done")


fh.close()
out.close()