def details(fname,lname='Cheena',age=90):
    global name,out
    name=fname+" "+lname # function variable > scope > local 
    out="hello" #local variable have more preference over the global variable in functions
    return name,age,out


out="Test" # script variable >scope > global 
v=details('Raj',age=89,lname='Sharma')
print(v)#"hello"

print(out)#"hello"
print(name)


