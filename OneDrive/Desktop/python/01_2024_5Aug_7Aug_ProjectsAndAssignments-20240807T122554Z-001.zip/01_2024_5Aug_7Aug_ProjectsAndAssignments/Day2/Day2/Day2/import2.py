import math as m
print(dir(m))

h=m.pi*4**2
print(h)

g=m.factorial(5)
print(g)

k=m.sin(m.pi/6)
print(k)

