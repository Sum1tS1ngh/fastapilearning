a=[1,2,3,4,5]
print(a)
print(id(a),type(a),len(a))
#update a list element / Value 
a[2]=78
# a.append((78,"Hello",76))
# a.insert(1, {56,89,34})
a.extend((45,"Hello",[89,90]))

print(a)
print(id(a),type(a),len(a))
