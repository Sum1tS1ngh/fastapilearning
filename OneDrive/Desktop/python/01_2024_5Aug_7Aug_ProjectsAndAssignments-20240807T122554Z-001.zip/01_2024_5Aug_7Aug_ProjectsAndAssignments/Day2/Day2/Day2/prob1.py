from random import randint 
for i in range(1,21):
    print(f"{i}.",end='')
    num=randint(0,100)
    if 10<num and num<60:
        if num > 43:
            print(f"The Value {num} is Large!")
        elif 35<num<=43:
            print("The Value {} is Medium".format(num))
            
        else:
            print(f"The Value {num} is Small!")
            
    else:
        print(f"The Value {num} is out of Range!")