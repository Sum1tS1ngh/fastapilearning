# obj=[1,1.2,'Hewllo',(5,6),1,1,1,1.2,"Hewllo",90]
# print(len(obj),type(obj))
# print(obj)

# set_obj=set(obj)
set_obj={1, 'Hewllo', 1.2, (5, 6), 90,90,90}
print(set_obj)
print(id(set_obj),type(set_obj),len(set_obj))
set_obj.add(89)
set_obj.discard("Hewllo")
print(set_obj)
print(id(set_obj),type(set_obj),len(set_obj))

for i in set_obj:
    print(i)