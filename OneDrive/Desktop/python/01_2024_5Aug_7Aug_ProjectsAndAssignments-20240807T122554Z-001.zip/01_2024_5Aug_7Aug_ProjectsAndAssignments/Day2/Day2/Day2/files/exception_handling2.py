try:
    fh=open('lines.txt','r')
    print(fh)
    
    for line in fh:
        print(line.strip())
    k=1/0
except IOError as m :
    print("Name Of the Error:-",m.__class__.__name__)
    print("Error Msg:-",m)
    fh1=open('out.txt','r')
    for line in fh1:
        print(line.strip())
    fh1.close()

except ZeroDivisionError as z:
    print("1/0 Error") 
    
       
except Exception as e:
    print("Error Solved!")
    print("Name Of the Error:-",e.__class__.__name__)
    print("Error Msg:-",e)
    
print("======================")
import datetime as dt
print(dt.datetime.now())