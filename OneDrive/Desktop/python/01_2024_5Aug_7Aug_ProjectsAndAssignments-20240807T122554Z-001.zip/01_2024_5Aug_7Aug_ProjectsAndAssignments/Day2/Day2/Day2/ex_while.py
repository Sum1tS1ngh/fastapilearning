a=10
b=20

while a<b:
    
    print(b,"Nishant")
#     a=a+1
    b=b-1