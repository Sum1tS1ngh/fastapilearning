d1={'name': ['Manish', 'Naresh', 'Test'], ('dept', 'other'): [['L&D', 'It'], [None, None]], 698757.78: '498&%#*%$jhgfg(*#'}
print("Dict d1:-",d1)
print(id(d1),type(d1),len(d1))
d2={"One":1,"Three":{"1":2987},"Two":[89,78]}
print("Dict d2:-",d2)
print(id(d2),type(d2),len(d2))
#######################
# Create dict d3 with the pairs of dict d1 and d2 ?
#without change in d1 and d2 
####lines 3 #########
# d3={}
# d3.update(d1)
# d3.update(d2)
####lines 2 ##########
# d3=d1.copy()
# d3.update(d2)
####line  1 ###########

print("Dict d3:-",d3)
print(id(d3),type(d3),len(d3))

print(d3 is d1)#F
print(d3 is d2)#F
