def demo():
    print("This is demo function.")
    
    
    
#call the function.
f=demo()#get return from the function#None
print(f)