d={'name':"Naresh",("dept",'other'):[['L&D',"It"],[None,None]],
   'name':["Manish",'Naresh',"Test"],
   698757.78:"498&%#*%$jhgfg(*#"}
print(d)
print(id(d),type(d),len(d))
##########################################
# v=d[("dept",'other')]#value=dict_object[Key]
# v=d.get('name',None)
# if v!=None:
#     print('Value:-',v)
# else:
#     print("Key Not Found!")
# for i in d: #keys :
#     print(i)

g=d.keys()#d.values()
print(g)
print(type(g))
values=[]
keys=[]
# keys=list(g)
for i in g:
    values.append(d[i])#value=dict_object[Key]
    keys.append(i)
print("This is Values:-",values)
print("Keys:-",keys)








