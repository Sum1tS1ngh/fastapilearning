def details(fname,lname,age):
    name=fname+" "+lname
    return name,age

#######################
#positional argument + Keyword argument
v=details('Manish',age=89,lname='Sharma')
print(v)

f=details('Raj','Meena',age=23)
print(f)


print("Manish",'Sharma',sep='   ',end=' ')
print("data")


print("Manish",'Sharma',end=' ',sep='   ')
print("data")

# print("Manish",end=' ','Sharma',sep='   ')
# print("data")


