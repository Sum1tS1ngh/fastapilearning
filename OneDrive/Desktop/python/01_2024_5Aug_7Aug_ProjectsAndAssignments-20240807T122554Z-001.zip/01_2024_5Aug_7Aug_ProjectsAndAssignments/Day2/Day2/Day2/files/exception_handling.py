try:
    fh=open('line.txt','r')
    print(fh)
    
    for line in fh:
        print(line.strip())
except:
    print("Error Solved!")
    
print("======================")
import datetime as dt
print(dt.datetime.now())