def details(fname,lname,age):
    name=fname+" "+lname
    return name,age

#######################
#positional argument
v=details('Manish','Sharma',89)
print(v)

f=details('Raj','Meena',23)
print(f)