#non-default argument +  default argument
def details(fname,lname='Cheena',age=90):
    name=fname+" "+lname
    return name,age

#######################
#positional argument + Keyword argument
v=details('Manish',age=89,lname='Sharma')
print(v)

f=details('amit')
print(f)



