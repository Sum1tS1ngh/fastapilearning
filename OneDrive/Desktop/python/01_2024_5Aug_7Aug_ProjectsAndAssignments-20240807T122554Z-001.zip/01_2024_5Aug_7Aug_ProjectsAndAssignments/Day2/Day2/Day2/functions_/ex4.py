def details(fname,lname,age):
    name=fname+" "+lname
    return name,age

#######################
#Keyword argument
v=details(lname='Sharma',fname='Manish',age=89)
print(v)

f=details(age=23,fname='Raj',lname='Meena')
print(f)