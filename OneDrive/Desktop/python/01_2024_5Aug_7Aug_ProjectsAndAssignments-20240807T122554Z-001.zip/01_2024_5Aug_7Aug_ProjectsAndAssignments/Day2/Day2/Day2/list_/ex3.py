a=[1,'1.2',1.2,"Hello",[56,89],(67,[90])]# list of the Values 

print(a)
print(id(a),type(a),len(a))
####################
# del a[3] # delete by index number 
# a.remove('Hello') ## delete by value 

# h=a.pop() # delete the last value from the list and also return the deleted value
h=a.pop(3) # delete the given index value from the list and also return the deleted value
print("Deleted Value :-",h)
print(a)
print(id(a),type(a),len(a))