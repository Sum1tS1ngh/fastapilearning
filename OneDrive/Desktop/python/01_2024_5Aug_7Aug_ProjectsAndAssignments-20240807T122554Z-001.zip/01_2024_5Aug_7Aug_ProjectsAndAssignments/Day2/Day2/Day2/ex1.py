import random 
print(dir(random))
g=random.randint(10,89)
print(g)

h=random.random()
print(h)

m=random.randrange(10,21,2)
print(m)

k=('Manish',"Naresh","Suresh","Ganesh")
j=random.sample(k,3)
print(j)