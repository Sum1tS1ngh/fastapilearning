d={'name': ['Manish', 'Naresh', 'Test'], ('dept', 'other'): [['L&D', 'It'], [None, None]], 698757.78: '498&%#*%$jhgfg(*#'}
print("Dict d:-",d)
print(id(d),type(d),len(d))
#########################
# del d['name']
v=d.pop('name1',None)
if v!=None:
    print("Deleted Value:-",v)
else:
    print("Key Not found! And pop returns:-",v)
print("Dict d:-",d)
print(id(d),type(d),len(d))

