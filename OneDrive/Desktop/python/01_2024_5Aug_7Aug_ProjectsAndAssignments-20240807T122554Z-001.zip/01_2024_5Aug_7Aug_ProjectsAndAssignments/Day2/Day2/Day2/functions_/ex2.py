def demo():
    print("This is demo function.")
    dept="L&D"
    age=[89]
    dept1="L&D"
    return dept,age #{'dept':dept ,'age':age}#[dept,age]
    
    
    
#call the function.
f=demo()#get return from the function
print(f)
print(type(f))
if type(f)==tuple or type(f)==list:
    #indexing 
    age=f[1]
    print("Age:-",age)
elif type(f)==dict:
    #keys 
    dept=f['dept']
    print("Dept:-",dept)
else:
    print("Other Data Type")