d1={'name': ['Manish', 'Naresh', 'Test'], ('dept', 'other'): [['L&D', 'It'], [None, None]], 698757.78: '498&%#*%$jhgfg(*#'}
print("Dict d1:-",d1)
print(id(d1),type(d1),len(d1))
d2={"One":1,"Three":{"1":2987},"Two":[89,78]}
print("Dict d2:-",d2)
print(id(d2),type(d2),len(d2))
##############update#######################
#update a value of an existing key ?
d1['name']="Test"
###add new pair within the dict object?
d1['newkey']=zip([1,2,3],[6,7,8])
##update dict d1 with the pairs of dict d2 ?
d1.update(d2)

print("Dict d1:-",d1)
print(id(d1),type(d1),len(d1))


print(d1 is d2)