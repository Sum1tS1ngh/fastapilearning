num=input("Enter the Number b/w 0-20:-")
if num.isdigit():
    num=int(num)
    if 0<=num<=20:
        fact=1
        for i in range(1,num+1):#range(1,2,1) > 1:2:1 > 1
            print(f"{i}*{fact}=",end="")
            fact=fact*i
            print(fact)
        print(f"The Value is {num} and Factorial is :- {fact}")
            
    else:
        print(f"The Value {num} is Out Of range(0-20).")
   
else:
    print(f"The Value {num} is <{type(num)}>Enter A valid Integer Value.")