import math 
print(dir(math))

h=math.pi*4**2
print(h)

g=math.factorial(5)
print(g)







# m=factorial(5)
# print(m)