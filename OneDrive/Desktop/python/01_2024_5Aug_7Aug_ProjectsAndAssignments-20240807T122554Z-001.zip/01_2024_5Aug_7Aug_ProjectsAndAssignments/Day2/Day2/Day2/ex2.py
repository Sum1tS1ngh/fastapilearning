from random import randint,random,randrange,sample

g=randint(10,89)
print(g)

h=random()
print(h)

m=randrange(10,21,2)
print(m)

k=('Manish',"Naresh","Suresh","Ganesh")
j=sample(k,3)
print(j)