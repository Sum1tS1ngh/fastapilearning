# obj=(1,1.2,"Hello",(89,89),[89,"Test"],{90,"Hello"},{"Name":"RamMohan"})
# print(len(obj),obj)
# 
# for loop_var in obj:
#     print(loop_var, "Nishant",type(loop_var))
#     
#     
# for i in ["Manish","Naresh","Suresh","Ganesh","Ramesh","Naresh"]:
#     if i not in ["Naresh","Suresh","Mona","Seema"]:
#         print(i,"Please join my Evening Party!")
   
   

# for i in ["Manish","Naresh","Suresh","Ganesh","Ramesh","Naresh"]:
#     if i in ["Naresh","Suresh","Mona","Seema"]:
#         pass#continue#break
#         print("This is pass block")
# 
#     print(i,"Please join my Evening Party!") 
#     
# print("Done")

# print Nishant 1000 Times ?

for i in range(1,1000+1):
    print(i,"Nishant")

# for i in range(10,22,2):
#     print(i)
    
    
    
    
    
    
    
    
    


